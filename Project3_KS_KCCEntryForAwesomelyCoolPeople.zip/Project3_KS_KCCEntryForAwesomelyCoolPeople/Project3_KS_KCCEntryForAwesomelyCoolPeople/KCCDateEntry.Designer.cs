﻿namespace Project3_KS_KCCEntryForAwesomelyCoolPeople
{
    partial class KCCDataEntryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.saveStudentButton = new System.Windows.Forms.Button();
            this.highSchoolButton = new System.Windows.Forms.Button();
            this.majorButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.highSchoolComboBox = new System.Windows.Forms.ComboBox();
            this.majorComboBox = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.seniorRadioButton = new System.Windows.Forms.RadioButton();
            this.juniorRadioButton = new System.Windows.Forms.RadioButton();
            this.sophomoreRadioButton = new System.Windows.Forms.RadioButton();
            this.freshmanRadioButton = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.creditsMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.studentNameTextBox = new System.Windows.Forms.TextBox();
            this.prospectsLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.entryErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.entryListBox = new System.Windows.Forms.ListBox();
            this.deleteRecordsButton = new System.Windows.Forms.Button();
            this.removeHighSchoolButton = new System.Windows.Forms.Button();
            this.removeMajorButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.entryErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.removeMajorButton);
            this.groupBox1.Controls.Add(this.removeHighSchoolButton);
            this.groupBox1.Controls.Add(this.saveStudentButton);
            this.groupBox1.Controls.Add(this.highSchoolButton);
            this.groupBox1.Controls.Add(this.majorButton);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.highSchoolComboBox);
            this.groupBox1.Controls.Add(this.majorComboBox);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.creditsMaskedTextBox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.studentNameTextBox);
            this.groupBox1.Location = new System.Drawing.Point(37, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(513, 362);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Input Student Information:";
            // 
            // saveStudentButton
            // 
            this.saveStudentButton.Location = new System.Drawing.Point(38, 307);
            this.saveStudentButton.Name = "saveStudentButton";
            this.saveStudentButton.Size = new System.Drawing.Size(121, 43);
            this.saveStudentButton.TabIndex = 11;
            this.saveStudentButton.Text = "Save &Student";
            this.saveStudentButton.UseVisualStyleBackColor = true;
            this.saveStudentButton.Click += new System.EventHandler(this.saveStudentButton_Click);
            // 
            // highSchoolButton
            // 
            this.highSchoolButton.Location = new System.Drawing.Point(369, 262);
            this.highSchoolButton.Name = "highSchoolButton";
            this.highSchoolButton.Size = new System.Drawing.Size(121, 23);
            this.highSchoolButton.TabIndex = 10;
            this.highSchoolButton.Text = "Add &High School";
            this.highSchoolButton.UseVisualStyleBackColor = true;
            this.highSchoolButton.Click += new System.EventHandler(this.highSchoolButton_Click);
            // 
            // majorButton
            // 
            this.majorButton.Location = new System.Drawing.Point(214, 262);
            this.majorButton.Name = "majorButton";
            this.majorButton.Size = new System.Drawing.Size(121, 23);
            this.majorButton.TabIndex = 9;
            this.majorButton.Text = "Add &Major";
            this.majorButton.UseVisualStyleBackColor = true;
            this.majorButton.Click += new System.EventHandler(this.majorButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(366, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "High School:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(214, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Choose a Major:";
            // 
            // highSchoolComboBox
            // 
            this.highSchoolComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.highSchoolComboBox.FormattingEnabled = true;
            this.highSchoolComboBox.Items.AddRange(new object[] {
            "Farrington",
            "Kaimuki",
            "Kaiser",
            "Kalani",
            "McKinley",
            "Moanalua",
            "Radford",
            "Roosevelt"});
            this.highSchoolComboBox.Location = new System.Drawing.Point(369, 145);
            this.highSchoolComboBox.Name = "highSchoolComboBox";
            this.highSchoolComboBox.Size = new System.Drawing.Size(121, 111);
            this.highSchoolComboBox.TabIndex = 6;
            // 
            // majorComboBox
            // 
            this.majorComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.majorComboBox.FormattingEnabled = true;
            this.majorComboBox.Items.AddRange(new object[] {
            "Accounting",
            "Business",
            "Information Technology",
            "Marketing"});
            this.majorComboBox.Location = new System.Drawing.Point(214, 145);
            this.majorComboBox.Name = "majorComboBox";
            this.majorComboBox.Size = new System.Drawing.Size(121, 111);
            this.majorComboBox.TabIndex = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.seniorRadioButton);
            this.groupBox2.Controls.Add(this.juniorRadioButton);
            this.groupBox2.Controls.Add(this.sophomoreRadioButton);
            this.groupBox2.Controls.Add(this.freshmanRadioButton);
            this.groupBox2.Location = new System.Drawing.Point(18, 133);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(155, 162);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Class:";
            // 
            // seniorRadioButton
            // 
            this.seniorRadioButton.AutoSize = true;
            this.seniorRadioButton.Location = new System.Drawing.Point(31, 121);
            this.seniorRadioButton.Name = "seniorRadioButton";
            this.seniorRadioButton.Size = new System.Drawing.Size(55, 17);
            this.seniorRadioButton.TabIndex = 3;
            this.seniorRadioButton.TabStop = true;
            this.seniorRadioButton.Text = "Senior";
            this.seniorRadioButton.UseVisualStyleBackColor = true;
            // 
            // juniorRadioButton
            // 
            this.juniorRadioButton.AutoSize = true;
            this.juniorRadioButton.Location = new System.Drawing.Point(31, 89);
            this.juniorRadioButton.Name = "juniorRadioButton";
            this.juniorRadioButton.Size = new System.Drawing.Size(53, 17);
            this.juniorRadioButton.TabIndex = 2;
            this.juniorRadioButton.TabStop = true;
            this.juniorRadioButton.Text = "Junior";
            this.juniorRadioButton.UseVisualStyleBackColor = true;
            // 
            // sophomoreRadioButton
            // 
            this.sophomoreRadioButton.AutoSize = true;
            this.sophomoreRadioButton.Location = new System.Drawing.Point(31, 54);
            this.sophomoreRadioButton.Name = "sophomoreRadioButton";
            this.sophomoreRadioButton.Size = new System.Drawing.Size(79, 17);
            this.sophomoreRadioButton.TabIndex = 1;
            this.sophomoreRadioButton.TabStop = true;
            this.sophomoreRadioButton.Text = "Sophomore";
            this.sophomoreRadioButton.UseVisualStyleBackColor = true;
            // 
            // freshmanRadioButton
            // 
            this.freshmanRadioButton.AutoSize = true;
            this.freshmanRadioButton.Location = new System.Drawing.Point(31, 19);
            this.freshmanRadioButton.Name = "freshmanRadioButton";
            this.freshmanRadioButton.Size = new System.Drawing.Size(71, 17);
            this.freshmanRadioButton.TabIndex = 0;
            this.freshmanRadioButton.TabStop = true;
            this.freshmanRadioButton.Text = "Freshman";
            this.freshmanRadioButton.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Number of Credits Completed:";
            // 
            // creditsMaskedTextBox
            // 
            this.creditsMaskedTextBox.Location = new System.Drawing.Point(188, 82);
            this.creditsMaskedTextBox.Mask = "000";
            this.creditsMaskedTextBox.Name = "creditsMaskedTextBox";
            this.creditsMaskedTextBox.Size = new System.Drawing.Size(66, 20);
            this.creditsMaskedTextBox.TabIndex = 2;
            this.creditsMaskedTextBox.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.creditsMaskedTextBox_MaskInputRejected);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(104, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Student Name:";
            // 
            // studentNameTextBox
            // 
            this.studentNameTextBox.Location = new System.Drawing.Point(188, 46);
            this.studentNameTextBox.Name = "studentNameTextBox";
            this.studentNameTextBox.Size = new System.Drawing.Size(170, 20);
            this.studentNameTextBox.TabIndex = 0;
            this.studentNameTextBox.TextChanged += new System.EventHandler(this.studentNameTextBox_TextChanged);
            // 
            // prospectsLabel
            // 
            this.prospectsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.prospectsLabel.Location = new System.Drawing.Point(52, 402);
            this.prospectsLabel.Name = "prospectsLabel";
            this.prospectsLabel.Size = new System.Drawing.Size(475, 81);
            this.prospectsLabel.TabIndex = 1;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(254, 501);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(81, 41);
            this.clearButton.TabIndex = 2;
            this.clearButton.Text = "&Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(406, 501);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(78, 41);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // entryErrorProvider
            // 
            this.entryErrorProvider.ContainerControl = this;
            // 
            // entryListBox
            // 
            this.entryListBox.FormattingEnabled = true;
            this.entryListBox.Location = new System.Drawing.Point(37, 392);
            this.entryListBox.Name = "entryListBox";
            this.entryListBox.Size = new System.Drawing.Size(513, 95);
            this.entryListBox.TabIndex = 4;
            // 
            // deleteRecordsButton
            // 
            this.deleteRecordsButton.Location = new System.Drawing.Point(97, 501);
            this.deleteRecordsButton.Name = "deleteRecordsButton";
            this.deleteRecordsButton.Size = new System.Drawing.Size(82, 41);
            this.deleteRecordsButton.TabIndex = 5;
            this.deleteRecordsButton.Text = "&Delete Records";
            this.deleteRecordsButton.UseVisualStyleBackColor = true;
            this.deleteRecordsButton.Click += new System.EventHandler(this.deleteRecordsButton_Click);
            // 
            // removeHighSchoolButton
            // 
            this.removeHighSchoolButton.Location = new System.Drawing.Point(369, 307);
            this.removeHighSchoolButton.Name = "removeHighSchoolButton";
            this.removeHighSchoolButton.Size = new System.Drawing.Size(121, 43);
            this.removeHighSchoolButton.TabIndex = 12;
            this.removeHighSchoolButton.Text = "Remove High School";
            this.removeHighSchoolButton.UseVisualStyleBackColor = true;
            this.removeHighSchoolButton.Click += new System.EventHandler(this.removeHighSchoolButton_Click);
            // 
            // removeMajorButton
            // 
            this.removeMajorButton.Location = new System.Drawing.Point(214, 307);
            this.removeMajorButton.Name = "removeMajorButton";
            this.removeMajorButton.Size = new System.Drawing.Size(121, 43);
            this.removeMajorButton.TabIndex = 13;
            this.removeMajorButton.Text = "Remove Major";
            this.removeMajorButton.UseVisualStyleBackColor = true;
            this.removeMajorButton.Click += new System.EventHandler(this.removeMajorButton_Click);
            // 
            // KCCDataEntryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(588, 554);
            this.Controls.Add(this.deleteRecordsButton);
            this.Controls.Add(this.entryListBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.prospectsLabel);
            this.Controls.Add(this.groupBox1);
            this.Name = "KCCDataEntryForm";
            this.Text = "KCC Data Entry";
            this.Load += new System.EventHandler(this.KCCDataEntryForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.entryErrorProvider)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox creditsMaskedTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox studentNameTextBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton seniorRadioButton;
        private System.Windows.Forms.RadioButton juniorRadioButton;
        private System.Windows.Forms.RadioButton sophomoreRadioButton;
        private System.Windows.Forms.RadioButton freshmanRadioButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox highSchoolComboBox;
        private System.Windows.Forms.ComboBox majorComboBox;
        private System.Windows.Forms.Button saveStudentButton;
        private System.Windows.Forms.Button highSchoolButton;
        private System.Windows.Forms.Button majorButton;
        private System.Windows.Forms.Label prospectsLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ErrorProvider entryErrorProvider;
        private System.Windows.Forms.ListBox entryListBox;
        private System.Windows.Forms.Button deleteRecordsButton;
        private System.Windows.Forms.Button removeMajorButton;
        private System.Windows.Forms.Button removeHighSchoolButton;
    }
}

